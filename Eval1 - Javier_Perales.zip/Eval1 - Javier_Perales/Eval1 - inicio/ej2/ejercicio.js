//Sin tocar ni el html ni el css
//Todos los elementos de la clase 'rojito' tienen que adoptar la clase 'verdecito'.

window.onload = function () {
    cambiarColor();
  
}

   document.getElementById("cambiar").addEventListener("click", cambiarColor);

let r = document.getElementsByName("*");



function cambiarColor() {

    for (x of r) {
        if (x.className === 'rojito') {
            x.classList.add("verdecito");
            x.classList.remove("rojito");
        } 
    }
}


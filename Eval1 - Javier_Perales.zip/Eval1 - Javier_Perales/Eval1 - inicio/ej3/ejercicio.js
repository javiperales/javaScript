/* Cargar un JSON con JAVASCRIPT con hijos y sin mostrar el apellido */
window.onload = function() {
    console.clear()
    verDatos();
    document.getElementById("btn").addEventListener("click", function(){
      ordenar(objeto);
    })
}

Array.prototype.unique = function() {
    return this.filter((x, i, a) => a.indexOf(x, i + 1) < 0);
}

var objeto;

function verDatos() {
    http = new XMLHttpRequest();
    http.onreadystatechange = mostrar;
    http.open("GET", "datos3.json", true);
    http.send(null);

    function mostrar() {
        //let respuesta = document.getElementById("container");
        let opciones = [];
        opciones.push("");
        let cad = "";
        //let objetoBackup = objeto;
        if (http.readyState == 4 && http.status == 200) {
            let r = http.responseText;
            objeto = JSON.parse(r);

            for (o in objeto) {
                var padre = objeto[o]
                for (colores of padre) {
                    //console.log(profe) // Devuelve cada uno de los elementos que tiene Profesores (4)
                    cad += "<tr>"
                    for (atributo in colores) {
                        if (!Array.isArray(colores[atributo])) { // si no es el módulo, que lo imprima directo
                            // si no, pondrá [object OBJECT] por que no estamos accediendo a cada atrib. del obj
                            cad += "<td>" + colores[atributo] + "</td> <br>";
                        } else { // accediendo al contenido de "módulo". Es un array
                            var modulo = colores[atributo]
                           
                        }
                        
                        if (atributo == "Nombre") { // no queremos filtrar por apellido
                            opciones.push(colores[atributo]);
                        }
                    }

                }
                cad += "</tr>"
                respuesta.innerHTML = cad
            }
            opciones = opciones.unique();
            crearSelect(opciones)
           
        }

        //console.log(opciones)

    } // si todo va bien

} //fin mostrar

function crearSelect(opciones) {

    let select = document.createElement("opciones")
    for (o of opciones) {
        let option = document.createElement("option")
        select.appendChild(option)
        option.innerHTML = o
    }
}



A = [5, 2, 3, 8, 9, 10, 1]

//Dado un vector de números enteros positivos calcula el número de elementos del vector que no son divisibles por ningún otro número del vector mayor que 1.
let cont=0;

 

for(let i=2; i<A.length; i++){
    
    if((A[i] % i == 0)){
        cont++;
    }
     console.log(cont)
    
}
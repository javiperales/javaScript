$(document).ready(function () {
    crearBarra();
    mover();
});



function crearBarra() {
    var cad = " "
    var cad2 = ""
    for (var i = 1; i < 33; i++) {
        cad += "<div class='cont'></div>"
        cad2 += "<div class='barra'></div>"
        $('.cont').append(cad2);
        $('#equ').append(cad);

    }
}




function mover() {
    $("#btnOn").click(function () {
        $('.barra').stop().animate({
            bottom: '600px'
        }, 100, 'linear');
    }, function () {
        $(this).stop().animate({
            bottom: '300px'
        }, 2000, 'linear');

    });
}

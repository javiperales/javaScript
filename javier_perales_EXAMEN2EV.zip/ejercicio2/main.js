var cadena = "";

var jsonCompleto;


$(function () {
    cargarAjax()

});

var cargarAjax = function () {
    $.ajax({
        url: './datos.json',
        dataType: 'json'

    }).done(function (respuesta) {
        console.log("elemento cargado");
        pintar(respuesta.archivos);

    }).fail(function () {
            document.write("fallo al cargar");
        }

    )
}
//cargar json

function pintar(respuesta) {
    jsonCompleto = respuesta
    for (variable of respuesta) {
        console.log(variable)
        for (o.link in variable.archivos) {
            console.log(o.link)
            cadena += "<p>" + o.link + "</p>"

        }
    }
    $("#container").html(cadena);



}

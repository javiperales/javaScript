 $(document).ready(function () {
     crearCubo();
     $(".ocultar").hide();
     mostrar();
 });


 var X = ['perro', 'gato', 'tigre', 'perro', 'cabra', 'oso', 'oso', 'gato', 'tigre', 'leon', 'lobo', 'cabra', 'lobo', 'leon', 'murcielago', 'murcielago']

 function crearCubo() {

     for (m of X) {

         cubo = "<div class='cubo' id='" + m + "'><p class='ocultar'>" + m + "</p></div>"


         $("#contenedor").append(cubo);
     }

 }

 function mostrar() {
     $(".cubo").click(function () {
         $(this().attr('id')).show();

     })

 }

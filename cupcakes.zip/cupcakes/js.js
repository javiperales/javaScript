window.onload=function(){
    cargarAjax();
    
    
}

function cargarAjax(){
   // alert("funciona");
    http= new XMLHttpRequest();
    http.onreadystatechange = mostrar;
    
    http.open("GET","./cupcakes.json", true);
    http.send(null);
    
    function mostrar(){
        console.log('estamos en mostrar');
        if(http.readyState==4 && http.status ==200){
            console.log('recibimos los datos ajax');
             
            var obj=JSON.parse(this.responseText);
           console.log(obj.cupcakes[0].ruta);
            for(let i=0 ; i<obj.cupcakes.length; i++){
                
                let conte= document.getElementById("cupcake"+i);
                let img=document.createElement("img");
                img.src=obj.cupcakes[i].ruta;
                conte.append(img);
                
                 console.log("entra aqui");
                let text=document.createElement("p");
                
                text.innerHTML=obj.cupcakes[i].nombre+"<br>";
                text.innerHTML+=obj.cupcakes[i].precio+"<br>";
                text.innerHTML+=obj.cupcakes[i].categorias+"<br>";
                conte.append(text);
               
            }
        }
        
        
     
        
        
        console.log('salimos mostrar');
    }
}




